# GOLDEN VISION SMART SCANNER — Android Native (Kotlin + Jetpack Compose)

هذا المجلد يحتوي على مشروع Android Native كامل وجاهز للتجميع إلى ملف `.apk` قابل للتثبيت على هاتفك، ومربوط مباشرة بخادم التحليل الحقيقي `POST /api/scanner/scan-screen`.

## المزايا المضمنة في كود Android الأصلي
- **زر عائم قابل للسحب (`WindowManager` + `SYSTEM_ALERT_WINDOW`)** يعمل فوق تطبيقات MetaTrader 5 وPocket Option وTradingView دون تغطية الشموع أو أزرار التداول.
- **التقاط الشاشة بموافقة المستخدم (`MediaProjection`)** لإرسال إطار واحد فقط عند الضغط على `SCAN NOW` مع إخفاء نافذة الماسح لحظياً أثناء الالتقاط.
- **خدمة أمامية متوافقة مع Android 14/15 (`FOREGROUND_SERVICE_MEDIA_PROJECTION` + `SPECIAL_USE`)** لضمان استمرار الزر العائم دون إغلاق النظام له.
- **إشعارات فورية (`POST_NOTIFICATIONS`)** عند صدور إشارة `BUY` أو `SELL`.
- **نسخ فوري** للزوج (Pocket Option) أو للصفقة بالكامل مع Entry/SL/TP1-TP3/Lot (MT5).

## طريقتان لإنتاج ملف APK وتثبيته على هاتفك

### الطريقة 1: عبر Android Studio (على الكمبيوتر)
1. افتح مجلد `android-app` في **Android Studio** (إصدار Ladybug أو أحدث مع JDK 17).
2. انتظر انتهاء Gradle Sync.
3. اختر **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. انقل الملف الناتج `app/build/outputs/apk/debug/app-debug.apk` إلى هاتفك Android وثبّته (أو وصّل الهاتف بـ USB واضغط **Run** للتثبيت المباشر).

### الطريقة 2: عبر GitHub Actions (بدون تثبيت Android Studio)
1. ارفع المشروع إلى مستودع GitHub.
2. افتح تبويب **Actions** وشغّل Workflow باسم **Build Golden Vision Android APK**.
3. بعد ~2 دقيقة حمّل ملف `golden-vision-smart-scanner-apk` مباشرة إلى هاتفك وثبّته.
