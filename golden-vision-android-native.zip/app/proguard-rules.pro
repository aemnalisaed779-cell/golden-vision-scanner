# Keep Gson model classes for /api/scanner/scan-screen
-keep class com.goldenvision.scanner.model.** { *; }
