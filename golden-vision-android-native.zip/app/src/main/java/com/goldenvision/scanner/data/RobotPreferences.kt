package com.goldenvision.scanner.data

import android.content.Context
import android.content.SharedPreferences

/**
 * Persists the floating laser-green robot's last dragged (x, y) coordinates,
 * size, enabled/paused state, and server settings across app restarts.
 */
class RobotPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("gv_robot_overlay_prefs", Context.MODE_PRIVATE)

    var lastX: Int
        get() = prefs.getInt("robot_x", -1)
        set(value) = prefs.edit().putInt("robot_x", value).apply()

    var lastY: Int
        get() = prefs.getInt("robot_y", -1)
        set(value) = prefs.edit().putInt("robot_y", value).apply()

    var robotSize: String
        get() = prefs.getString("robot_size", "md") ?: "md"
        set(value) = prefs.edit().putString("robot_size", value).apply()

    var robotEnabled: Boolean
        get() = prefs.getBoolean("robot_enabled", true)
        set(value) = prefs.edit().putBoolean("robot_enabled", value).apply()

    var robotPaused: Boolean
        get() = prefs.getBoolean("robot_paused", false)
        set(value) = prefs.edit().putBoolean("robot_paused", value).apply()

    var serverUrl: String
        get() = prefs.getString(
            "server_url",
            "https://ais-pre-3cubqj27l2ymyqrki2jzlu-706520091007.europe-west1.run.app"
        ) ?: "https://ais-pre-3cubqj27l2ymyqrki2jzlu-706520091007.europe-west1.run.app"
        set(value) = prefs.edit().putString("server_url", value).apply()

    var accountBalance: Double
        get() = prefs.getFloat("account_balance", 1000f).toDouble()
        set(value) = prefs.edit().putFloat("account_balance", value.toFloat()).apply()

    var riskPercent: Double
        get() = prefs.getFloat("risk_percent", 1.0f).toDouble()
        set(value) = prefs.edit().putFloat("risk_percent", value.toFloat()).apply()

    fun savePosition(x: Int, y: Int) {
        prefs.edit()
            .putInt("robot_x", x)
            .putInt("robot_y", y)
            .apply()
    }
}
