package com.goldenvision.scanner.network

import com.goldenvision.scanner.model.ScanAnalysisResult
import com.goldenvision.scanner.model.ScanScreenRequest
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class ScannerApiClient(
    private val baseUrl: String
) {
    private val gson = Gson()
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(35, TimeUnit.SECONDS)
        .writeTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun scanScreenFrame(
        imageBase64DataUrl: String,
        accountBalance: Double = 1000.0,
        riskPercent: Double = 1.0
    ): Result<ScanAnalysisResult> = withContext(Dispatchers.IO) {
        try {
            val cleanBase = baseUrl.trimEnd('/')
            val payload = ScanScreenRequest(
                imageBase64 = imageBase64DataUrl,
                accountBalance = accountBalance,
                riskPercent = riskPercent
            )
            val body = gson.toJson(payload).toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url("$cleanBase/api/scanner/scan-screen")
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("HTTP ${response.code}: $raw")
                    )
                }
                val parsed = gson.fromJson(raw, ScanAnalysisResult::class.java)
                Result.success(parsed)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
