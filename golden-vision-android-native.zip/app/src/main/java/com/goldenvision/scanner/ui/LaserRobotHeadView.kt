package com.goldenvision.scanner.ui

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator

/**
 * Custom futuristic laser-green glowing AI Robot Head floating button
 * with glowing eyes, metallic dark chassis, golden crest, and subtle breathing motion.
 */
class LaserRobotHeadView(context: Context) : View(context) {

    private var paused = false
    private var pulsePhase = 0f

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val chassisPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0D1117")
        style = Paint.Style.FILL
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val visorPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#05080C")
        style = Paint.Style.FILL
    }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val eyeCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val goldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#D4AF37")
        style = Paint.Style.FILL
    }

    private val pulseAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1600L
        repeatMode = ValueAnimator.REVERSE
        repeatCount = ValueAnimator.INFINITE
        interpolator = AccelerateDecelerateInterpolator()
        addUpdateListener { anim ->
            pulsePhase = anim.animatedValue as Float
            translationY = if (paused) 0f else (pulsePhase - 0.5f) * 6f
            invalidate()
        }
    }

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun setPausedState(isPaused: Boolean) {
        paused = isPaused
        if (paused) {
            translationY = 0f
        }
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!pulseAnimator.isStarted) {
            pulseAnimator.start()
        }
    }

    override fun onDetachedFromWindow() {
        pulseAnimator.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) * 0.46f

        val laserColor = if (paused) Color.parseColor("#6B7280") else Color.parseColor("#00FF66")
        val eyeCoreColor = if (paused) Color.parseColor("#9CA3AF") else Color.parseColor("#9EFFC4")

        // Laser-green outer glow aura
        val glowAlpha = if (paused) 45 else (110 + (pulsePhase * 65).toInt())
        glowPaint.shader = RadialGradient(
            cx,
            cy,
            r * 1.12f,
            intArrayOf(
                Color.argb(glowAlpha, Color.red(laserColor), Color.green(laserColor), Color.blue(laserColor)),
                Color.TRANSPARENT
            ),
            floatArrayOf(0.45f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, r * 1.1f, glowPaint)

        // Outer circular dark orb backing
        chassisPaint.color = Color.parseColor("#F2070B0E")
        canvas.drawCircle(cx, cy, r * 0.88f, chassisPaint)

        strokePaint.color = laserColor
        strokePaint.strokeWidth = r * 0.08f
        canvas.drawCircle(cx, cy, r * 0.88f, strokePaint)

        // Top antenna
        strokePaint.strokeWidth = r * 0.06f
        canvas.drawLine(cx, cy - r * 0.72f, cx, cy - r * 0.52f, strokePaint)
        eyePaint.color = laserColor
        canvas.drawCircle(cx, cy - r * 0.74f, r * 0.07f, eyePaint)

        // Robot head silhouette
        val headRect = RectF(
            cx - r * 0.52f,
            cy - r * 0.48f,
            cx + r * 0.52f,
            cy + r * 0.46f
        )
        chassisPaint.color = Color.parseColor("#131922")
        canvas.drawRoundRect(headRect, r * 0.24f, r * 0.24f, chassisPaint)
        strokePaint.strokeWidth = r * 0.055f
        canvas.drawRoundRect(headRect, r * 0.24f, r * 0.24f, strokePaint)

        // Gold forehead crest (Golden Vision identity)
        val crest = Path().apply {
            moveTo(cx - r * 0.18f, cy - r * 0.38f)
            lineTo(cx + r * 0.18f, cy - r * 0.38f)
            lineTo(cx + r * 0.11f, cy - r * 0.27f)
            lineTo(cx - r * 0.11f, cy - r * 0.27f)
            close()
        }
        canvas.drawPath(crest, goldPaint)

        // Dark Visor
        val visorRect = RectF(
            cx - r * 0.40f,
            cy - r * 0.18f,
            cx + r * 0.40f,
            cy + r * 0.16f
        )
        canvas.drawRoundRect(visorRect, r * 0.16f, r * 0.16f, visorPaint)

        // Glowing Laser Eyes
        val eyeRx = r * 0.11f
        val eyeRy = if (paused) r * 0.035f else r * 0.085f
        eyePaint.color = laserColor
        eyeCorePaint.color = eyeCoreColor

        val leftEye = RectF(cx - r * 0.18f - eyeRx, cy - 0.01f * r - eyeRy, cx - r * 0.18f + eyeRx, cy - 0.01f * r + eyeRy)
        val rightEye = RectF(cx + r * 0.18f - eyeRx, cy - 0.01f * r - eyeRy, cx + r * 0.18f + eyeRx, cy - 0.01f * r + eyeRy)
        canvas.drawOval(leftEye, eyePaint)
        canvas.drawOval(rightEye, eyePaint)

        canvas.drawCircle(cx - r * 0.18f, cy - 0.01f * r, eyeRy * 0.5f, eyeCorePaint)
        canvas.drawCircle(cx + r * 0.18f, cy - 0.01f * r, eyeRy * 0.5f, eyeCorePaint)

        // Scanner core bar (mouth)
        val barRect = RectF(
            cx - r * 0.18f,
            cy + r * 0.27f,
            cx + r * 0.18f,
            cy + r * 0.34f
        )
        canvas.drawRoundRect(barRect, r * 0.04f, r * 0.04f, eyePaint)
    }
}
