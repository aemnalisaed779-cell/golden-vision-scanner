package com.goldenvision.scanner.model

import com.google.gson.annotations.SerializedName

data class ScanScreenRequest(
    val imageBase64: String,
    val manualPair: String? = null,
    val manualTimeframe: String? = null,
    val manualPlatform: String? = null,
    val accountBalance: Double = 1000.0,
    val riskPercent: Double = 1.0
)

data class PocketOptionSignal(
    val direction: String = "WAIT",
    val suggestedExpiry: String = "—",
    val originalPair: String = "—",
    val signalTime: String = "",
    val confidence: Int = 0,
    val rationale: List<String> = emptyList()
)

data class MT5Signal(
    val direction: String = "WAIT",
    val entry: Double? = null,
    val stopLoss: Double? = null,
    val tp1: Double? = null,
    val tp2: Double? = null,
    val tp3: Double? = null,
    val riskReward: String = "—",
    val suggestedLotSize: Double? = null,
    val rationale: List<String> = emptyList()
)

data class ScanAnalysisResult(
    val id: String = "",
    val timestamp: String = "",
    val platform: String = "Unknown",
    val connectionMode: String = "SCREEN_VISION_ONLY",
    val connectionDisclosure: String = "",
    val pair: String = "UNKNOWN",
    val displayPair: String = "غير محدد",
    val assetCategory: String = "Forex",
    val timeframe: String = "5m",
    val currentPrice: Double? = null,
    val priceSource: String = "",
    val dataFreshnessStatus: String = "DISCONNECTED",
    val direction: String = "WAIT",
    val trend: String = "NEUTRAL",
    val confidence: Int = 0,
    val pocketOption: PocketOptionSignal = PocketOptionSignal(),
    val mt5: MT5Signal = MT5Signal(),
    val protectionWarnings: List<String> = emptyList(),
    @SerializedName("needsManualSelection")
    val needsManualSelection: Boolean = false
)
