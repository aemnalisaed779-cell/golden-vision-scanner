package com.goldenvision.scanner.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.goldenvision.scanner.MainActivity
import com.goldenvision.scanner.capture.ScreenCaptureManager
import com.goldenvision.scanner.data.RobotPreferences
import com.goldenvision.scanner.model.ScanAnalysisResult
import com.goldenvision.scanner.network.ScannerApiClient
import com.goldenvision.scanner.ui.LaserRobotHeadView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.abs

class GoldenVisionOverlayService : Service() {

    companion object {
        const val ACTION_START = "com.goldenvision.scanner.START"
        const val ACTION_STOP = "com.goldenvision.scanner.STOP"
        const val ACTION_UPDATE_SETTINGS = "com.goldenvision.scanner.UPDATE_SETTINGS"
        const val ACTION_TOGGLE_PAUSE = "com.goldenvision.scanner.TOGGLE_PAUSE"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_MEDIA_DATA = "extra_media_data"
        const val EXTRA_SERVER_URL = "extra_server_url"
        const val EXTRA_BALANCE = "extra_balance"
        const val EXTRA_RISK_PERCENT = "extra_risk_percent"
        const val EXTRA_ROBOT_SIZE = "extra_robot_size" // "sm" | "md" | "lg"
        const val EXTRA_ROBOT_VISIBLE = "extra_robot_visible"
        const val EXTRA_ROBOT_PAUSED = "extra_robot_paused"
        const val EXTRA_ROBOT_PRESET = "extra_robot_preset" // "top-left" | "top-right" | "mid-left" | "mid-right"

        private const val CHANNEL_SERVICE_ID = "gv_overlay_service"
        private const val CHANNEL_SIGNALS_ID = "gv_instant_signals"
        private const val NOTIF_SERVICE_ID = 1001
        private const val NOTIF_SIGNAL_ID = 2001
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private lateinit var captureManager: ScreenCaptureManager
    private lateinit var prefs: RobotPreferences
    private var apiClient: ScannerApiClient? = null

    private var rootContainer: LinearLayout? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private var robotHeadView: LaserRobotHeadView? = null
    private var hudCard: LinearLayout? = null
    private var statusText: TextView? = null
    private var signalTitle: TextView? = null
    private var detailsText: TextView? = null
    private var scanButton: Button? = null
    private var pauseButton: TextView? = null
    private var copyButton: Button? = null

    private var lastResult: ScanAnalysisResult? = null
    private var accountBalance: Double = 1000.0
    private var riskPercent: Double = 1.0
    private var robotSize: String = "md"
    private var robotVisible: Boolean = true
    private var robotPaused: Boolean = false
    private var isScanning = false

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        captureManager = ScreenCaptureManager(this)
        prefs = RobotPreferences(this)
        robotSize = prefs.robotSize
        robotVisible = prefs.robotEnabled
        robotPaused = prefs.robotPaused
        accountBalance = prefs.accountBalance
        riskPercent = prefs.riskPercent
        createNotificationChannels()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                prefs.robotEnabled = false
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_PAUSE -> {
                robotPaused = !robotPaused
                prefs.robotPaused = robotPaused
                applyRobotVisualSettings(null)
                return START_STICKY
            }
            ACTION_UPDATE_SETTINGS -> {
                robotSize = intent.getStringExtra(EXTRA_ROBOT_SIZE) ?: robotSize
                robotVisible = intent.getBooleanExtra(EXTRA_ROBOT_VISIBLE, robotVisible)
                robotPaused = intent.getBooleanExtra(EXTRA_ROBOT_PAUSED, robotPaused)
                prefs.robotSize = robotSize
                prefs.robotEnabled = robotVisible
                prefs.robotPaused = robotPaused
                val preset = intent.getStringExtra(EXTRA_ROBOT_PRESET)
                applyRobotVisualSettings(preset)
                return START_STICKY
            }
        }

        val serverUrl = intent?.getStringExtra(EXTRA_SERVER_URL) ?: prefs.serverUrl
        accountBalance = intent?.getDoubleExtra(EXTRA_BALANCE, prefs.accountBalance) ?: prefs.accountBalance
        riskPercent = intent?.getDoubleExtra(EXTRA_RISK_PERCENT, prefs.riskPercent) ?: prefs.riskPercent
        robotSize = intent?.getStringExtra(EXTRA_ROBOT_SIZE) ?: prefs.robotSize
        robotVisible = intent?.getBooleanExtra(EXTRA_ROBOT_VISIBLE, prefs.robotEnabled) ?: prefs.robotEnabled
        robotPaused = intent?.getBooleanExtra(EXTRA_ROBOT_PAUSED, prefs.robotPaused) ?: prefs.robotPaused
        prefs.serverUrl = serverUrl
        prefs.accountBalance = accountBalance
        prefs.riskPercent = riskPercent
        prefs.robotSize = robotSize
        prefs.robotEnabled = robotVisible
        prefs.robotPaused = robotPaused

        val preset = intent?.getStringExtra(EXTRA_ROBOT_PRESET)
        apiClient = ScannerApiClient(serverUrl)

        startForegroundCompliant()

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val mediaData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_MEDIA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_MEDIA_DATA)
        }

        if (resultCode != 0 && mediaData != null) {
            captureManager.initialize(resultCode, mediaData)
        }

        if (rootContainer == null) {
            attachFloatingOverlay()
        }
        applyRobotVisualSettings(preset)

        // Ensures overlay service stays alive in background even when user leaves MainActivity
        return START_STICKY
    }

    private fun startForegroundCompliant() {
        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val pauseIntent = Intent(this, GoldenVisionOverlayService::class.java).apply {
            action = ACTION_TOGGLE_PAUSE
        }
        val pausePending = PendingIntent.getService(
            this, 2, pauseIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, GoldenVisionOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPending = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_SERVICE_ID)
            .setContentTitle("GOLDEN VISION SMART SCANNER")
            .setContentText("الروبوت الأخضر العائم نشط فوق MT5 وPocket Option")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف مؤقت", pausePending)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إغلاق", stopPending)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val fgsType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            } else {
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            }
            startForeground(NOTIF_SERVICE_ID, notification, fgsType)
        } else {
            startForeground(NOTIF_SERVICE_ID, notification)
        }
    }

    private fun sizeDpForKey(key: String): Int = when (key) {
        "sm" -> 52
        "lg" -> 76
        else -> 64
    }

    private fun applyRobotVisualSettings(preset: String?) {
        val dp = resources.displayMetrics.density
        val orbPx = (sizeDpForKey(robotSize) * dp).toInt()
        robotHeadView?.let { v ->
            v.layoutParams = LinearLayout.LayoutParams(orbPx, orbPx)
            v.setPausedState(robotPaused)
            v.requestLayout()
        }
        rootContainer?.visibility = if (robotVisible) View.VISIBLE else View.GONE
        scanButton?.isEnabled = !robotPaused && !isScanning
        pauseButton?.text = if (robotPaused) "استئناف" else "إيقاف مؤقت"
        if (robotPaused) {
            statusText?.text = "الروبوت متوقف مؤقتاً"
        }

        val params = overlayParams
        val root = rootContainer
        if (preset != null && params != null && root != null) {
            val screenW = resources.displayMetrics.widthPixels
            val screenH = resources.displayMetrics.heightPixels
            val margin = (18 * dp).toInt()
            when (preset) {
                "top-left" -> {
                    params.x = margin
                    params.y = (110 * dp).toInt()
                }
                "top-right" -> {
                    params.x = (screenW - orbPx - margin).coerceAtLeast(margin)
                    params.y = (110 * dp).toInt()
                }
                "mid-left" -> {
                    params.x = margin
                    params.y = (screenH * 0.42f).toInt()
                }
                "mid-right" -> {
                    params.x = (screenW - orbPx - margin).coerceAtLeast(margin)
                    params.y = (screenH * 0.42f).toInt()
                }
            }
            try {
                windowManager.updateViewLayout(root, params)
                prefs.savePosition(params.x, params.y)
            } catch (_: Exception) {}
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachFloatingOverlay() {
        val dp = resources.displayMetrics.density
        fun Int.dpPx(): Int = (this * dp).toInt()

        val savedX = prefs.lastX
        val savedY = prefs.lastY

        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (savedX >= 0) savedX else 20.dpPx()
            y = if (savedY >= 0) savedY else 140.dpPx()
        }
        overlayParams = layoutParams

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.START
        }

        // Laser-Green Glowing AI Robot Head Floating Orb
        val orbPx = sizeDpForKey(robotSize).dpPx()
        val robotView = LaserRobotHeadView(this).apply {
            layoutParams = LinearLayout.LayoutParams(orbPx, orbPx)
        }

        // Expandable HUD Panel (minimized by default until user taps robot)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(12.dpPx(), 10.dpPx(), 12.dpPx(), 10.dpPx())
            background = GradientDrawable().apply {
                cornerRadius = 12.dpPx().toFloat()
                setColor(Color.parseColor("#F20B0F14"))
                setStroke(1.dpPx(), Color.parseColor("#6600FF66"))
            }
            layoutParams = LinearLayout.LayoutParams(270.dpPx(), LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                topMargin = 8.dpPx()
            }
        }

        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleTv = TextView(this).apply {
            text = "GOLDEN VISION AI"
            textSize = 12f
            setTextColor(Color.parseColor("#F5D76E"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        val pauseBtn = TextView(this).apply {
            text = "إيقاف مؤقت"
            textSize = 11f
            setTextColor(Color.parseColor("#9CA3AF"))
            setPadding(6.dpPx(), 4.dpPx(), 6.dpPx(), 4.dpPx())
            setOnClickListener {
                robotPaused = !robotPaused
                applyRobotVisualSettings(null)
            }
        }
        val hideBtn = TextView(this).apply {
            text = "إغلاق ✕"
            textSize = 11f
            setTextColor(Color.parseColor("#EF4444"))
            setPadding(6.dpPx(), 4.dpPx(), 6.dpPx(), 4.dpPx())
            setOnClickListener { stopSelf() }
        }
        headerRow.addView(titleTv)
        headerRow.addView(pauseBtn)
        headerRow.addView(hideBtn)

        val scanBtn = Button(this).apply {
            text = "SCAN NOW"
            textSize = 12f
            setTextColor(Color.parseColor("#05080A"))
            background = GradientDrawable().apply {
                cornerRadius = 8.dpPx().toFloat()
                setColor(Color.parseColor("#00FF66"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                38.dpPx()
            ).apply {
                topMargin = 8.dpPx()
            }
            setOnClickListener { triggerScreenScan() }
        }

        val sigTv = TextView(this).apply {
            text = "جاهز للمسح الفوري"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 8.dpPx(), 0, 2.dpPx())
        }

        val statusTv = TextView(this).apply {
            text = "اضغط على رأس الروبوت لتصغير اللوحة دون إغلاقها"
            textSize = 11f
            setTextColor(Color.parseColor("#9CA3AF"))
        }

        val detailTv = TextView(this).apply {
            text = ""
            textSize = 11f
            setTextColor(Color.parseColor("#E5E7EB"))
            setPadding(0, 6.dpPx(), 0, 6.dpPx())
        }

        val copyBtn = Button(this).apply {
            text = "نسخ الإشارة"
            textSize = 11f
            visibility = View.GONE
            setTextColor(Color.parseColor("#F5D76E"))
            background = GradientDrawable().apply {
                cornerRadius = 6.dpPx().toFloat()
                setColor(Color.parseColor("#22D4AF37"))
                setStroke(1.dpPx(), Color.parseColor("#66D4AF37"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                34.dpPx()
            )
            setOnClickListener { copyLatestSignal() }
        }

        card.addView(headerRow)
        card.addView(scanBtn)
        card.addView(sigTv)
        card.addView(statusTv)
        card.addView(detailTv)
        card.addView(copyBtn)

        root.addView(robotView)
        root.addView(card)

        // Smooth dragging + tap-to-toggle expand/minimize without closing
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        robotView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 6 || abs(dy) > 6) moved = true
                    layoutParams.x = initialX + dx
                    layoutParams.y = initialY + dy
                    windowManager.updateViewLayout(root, layoutParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        card.visibility = if (card.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    } else {
                        prefs.savePosition(layoutParams.x, layoutParams.y)
                    }
                    true
                }
                else -> false
            }
        }

        rootContainer = root
        robotHeadView = robotView
        hudCard = card
        signalTitle = sigTv
        statusText = statusTv
        detailsText = detailTv
        scanButton = scanBtn
        pauseButton = pauseBtn
        copyButton = copyBtn

        windowManager.addView(root, layoutParams)
    }

    private fun triggerScreenScan() {
        if (isScanning || robotPaused) return
        if (!captureManager.isReady()) {
            statusText?.text = "يرجى منح صلاحية MediaProjection من تطبيق Golden Vision أولاً"
            return
        }

        isScanning = true
        scanButton?.isEnabled = false
        scanButton?.text = "جاري المسح..."
        statusText?.text = "التقاط الشاشة وقراءة الشارت..."

        serviceScope.launch {
            hudCard?.visibility = View.INVISIBLE
            val frame = captureManager.captureSingleFrameBase64()
            hudCard?.visibility = View.VISIBLE

            if (frame == null) {
                isScanning = false
                scanButton?.isEnabled = !robotPaused
                scanButton?.text = "SCAN NOW"
                statusText?.text = "تعذر التقاط إطار الشاشة"
                return@launch
            }

            val client = apiClient ?: return@launch
            val response = client.scanScreenFrame(frame, accountBalance, riskPercent)

            withContext(Dispatchers.Main) {
                isScanning = false
                scanButton?.isEnabled = !robotPaused
                scanButton?.text = "SCAN NOW"

                response.onSuccess { res ->
                    lastResult = res
                    renderResult(res)
                    if (res.direction == "BUY" || res.direction == "SELL") {
                        sendInstantSignalNotification(res)
                    }
                }.onFailure { err ->
                    signalTitle?.text = "WAIT (خطأ اتصال)"
                    signalTitle?.setTextColor(Color.parseColor("#F59E0B"))
                    statusText?.text = err.message ?: "تعذر الاتصال بالخادم"
                }
            }
        }
    }

    private fun renderResult(res: ScanAnalysisResult) {
        val color = when (res.direction) {
            "BUY" -> Color.parseColor("#10B981")
            "SELL" -> Color.parseColor("#EF4444")
            else -> Color.parseColor("#F59E0B")
        }
        signalTitle?.text = "${res.displayPair} — ${res.direction} (${res.confidence}%)"
        signalTitle?.setTextColor(color)
        statusText?.text = "${res.platform} · ${res.timeframe} · السعر: ${res.currentPrice ?: "—"}"

        val isPocket = res.platform.contains("Pocket", ignoreCase = true) ||
            res.platform.contains("Binolla", ignoreCase = true)

        detailsText?.text = if (isPocket) {
            "الاتجاه: ${res.pocketOption.direction} | المدة: ${res.pocketOption.suggestedExpiry}\n" +
                (res.protectionWarnings.firstOrNull() ?: "قراءة الشاشة + تحقق البيانات الحقيقية")
        } else {
            "Entry: ${res.mt5.entry ?: "—"} | SL: ${res.mt5.stopLoss ?: "—"}\n" +
                "TP1: ${res.mt5.tp1 ?: "—"} | TP2: ${res.mt5.tp2 ?: "—"} | TP3: ${res.mt5.tp3 ?: "—"}\n" +
                "Lot: ${res.mt5.suggestedLotSize ?: "—"} · " +
                (res.protectionWarnings.firstOrNull() ?: "")
        }

        copyButton?.visibility = View.VISIBLE
        copyButton?.text = if (isPocket) "نسخ الزوج (${res.displayPair})" else "نسخ الصفقة بالكامل"
    }

    private fun copyLatestSignal() {
        val res = lastResult ?: return
        val isPocket = res.platform.contains("Pocket", ignoreCase = true) ||
            res.platform.contains("Binolla", ignoreCase = true)
        val text = if (isPocket) {
            res.pocketOption.originalPair
        } else {
            "GOLDEN VISION (${res.platform})\nPair: ${res.displayPair} (${res.timeframe})\nSignal: ${res.mt5.direction}\nEntry: ${res.mt5.entry}\nSL: ${res.mt5.stopLoss}\nTP1: ${res.mt5.tp1}\nTP2: ${res.mt5.tp2}\nTP3: ${res.mt5.tp3}\nLot: ${res.mt5.suggestedLotSize}"
        }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("GoldenVisionSignal", text))
        Toast.makeText(this, "تم النسخ بنجاح", Toast.LENGTH_SHORT).show()
    }

    private fun sendInstantSignalNotification(res: ScanAnalysisResult) {
        val manager = getSystemService(NotificationManager::class.java)
        val notif = NotificationCompat.Builder(this, CHANNEL_SIGNALS_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("GOLDEN VISION: ${res.direction} ${res.displayPair}")
            .setContentText("${res.platform} (${res.timeframe}) · الثقة ${res.confidence}% · السعر ${res.currentPrice ?: ""}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        manager.notify(NOTIF_SIGNAL_ID, notif)
    }

    private fun createNotificationChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        val serviceChannel = NotificationChannel(
            CHANNEL_SERVICE_ID,
            "خدمة الروبوت العائم",
            NotificationManager.IMPORTANCE_LOW
        )
        val signalChannel = NotificationChannel(
            CHANNEL_SIGNALS_ID,
            "إشعارات إشارات التداول الفورية",
            NotificationManager.IMPORTANCE_HIGH
        )
        manager.createNotificationChannel(serviceChannel)
        manager.createNotificationChannel(signalChannel)
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        captureManager.release()
        rootContainer?.let {
            try {
                windowManager.removeView(it)
            } catch (_: Exception) {}
        }
        rootContainer = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
