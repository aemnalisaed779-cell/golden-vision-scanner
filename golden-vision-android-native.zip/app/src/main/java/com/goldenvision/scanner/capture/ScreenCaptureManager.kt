package com.goldenvision.scanner.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.Looper
import android.util.Base64
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * Captures a single screen frame using Android MediaProjection with explicit user consent.
 */
class ScreenCaptureManager(private val context: Context) {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    fun initialize(resultCode: Int, data: Intent): Boolean {
        val manager =
            context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection?.stop()
        mediaProjection = manager.getMediaProjection(resultCode, data)
        return mediaProjection != null
    }

    fun isReady(): Boolean = mediaProjection != null

    suspend fun captureSingleFrameBase64(): String? = suspendCancellableCoroutine { cont ->
        val projection = mediaProjection
        if (projection == null) {
            cont.resume(null)
            return@suspendCancellableCoroutine
        }

        val metrics = context.resources.displayMetrics
        val width = metrics.widthPixels.coerceAtMost(1080)
        val height = (metrics.heightPixels.toFloat() / metrics.widthPixels.toFloat() * width).toInt()
        val density = metrics.densityDpi

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader

        val handler = Handler(Looper.getMainLooper())
        var captured = false

        reader.setOnImageAvailableListener({ r ->
            if (captured) return@setOnImageAvailableListener
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            captured = true
            try {
                val plane = image.planes[0]
                val buffer = plane.buffer
                val pixelStride = plane.pixelStride
                val rowStride = plane.rowStride
                val rowPadding = rowStride - pixelStride * width

                val fullBitmap = Bitmap.createBitmap(
                    width + rowPadding / pixelStride,
                    height,
                    Bitmap.Config.ARGB_8888
                )
                fullBitmap.copyPixelsFromBuffer(buffer)
                val cropped = Bitmap.createBitmap(fullBitmap, 0, 0, width, height)
                fullBitmap.recycle()

                val stream = ByteArrayOutputStream()
                cropped.compress(Bitmap.CompressFormat.JPEG, 82, stream)
                cropped.recycle()

                val b64 = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
                cleanupCaptureResources()
                if (cont.isActive) cont.resume("data:image/jpeg;base64,$b64")
            } catch (_: Exception) {
                cleanupCaptureResources()
                if (cont.isActive) cont.resume(null)
            } finally {
                image.close()
            }
        }, handler)

        virtualDisplay = projection.createVirtualDisplay(
            "GoldenVisionCapture",
            width,
            height,
            density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            handler
        )

        cont.invokeOnCancellation {
            cleanupCaptureResources()
        }
    }

    private fun cleanupCaptureResources() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
    }

    fun release() {
        cleanupCaptureResources()
        mediaProjection?.stop()
        mediaProjection = null
    }
}
