package com.goldenvision.scanner

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.goldenvision.scanner.data.RobotPreferences
import com.goldenvision.scanner.service.GoldenVisionOverlayService

private val GvCanvas = Color(0xFF090B0F)
private val GvSurface = Color(0xFF11151C)
private val GvGold = Color(0xFFD4AF37)
private val GvGoldBright = Color(0xFFF5D76E)
private val GvLaser = Color(0xFF00FF66)
private val GvBorder = Color(0x18FFFFFF)
private val GvMuted = Color(0xFF9CA3AF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                MaterialTheme(
                    colorScheme = darkColorScheme(
                        primary = GvGold,
                        background = GvCanvas,
                        surface = GvSurface,
                        onPrimary = GvCanvas,
                        onBackground = Color.White,
                        onSurface = Color.White
                    )
                ) {
                    GoldenVisionHomeScreen()
                }
            }
        }
    }
}

@Composable
fun GoldenVisionHomeScreen() {
    val context = LocalContext.current
    val prefs = remember { RobotPreferences(context) }

    var hasOverlayPerm by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var hasNotifPerm by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else true
        )
    }

    var serverUrl by remember { mutableStateOf(prefs.serverUrl) }
    var balanceText by remember { mutableStateOf(prefs.accountBalance.toString()) }
    var riskText by remember { mutableStateOf(prefs.riskPercent.toString()) }

    // Persisted Laser Robot customization state
    var robotVisible by remember { mutableStateOf(prefs.robotEnabled) }
    var robotPaused by remember { mutableStateOf(prefs.robotPaused) }
    var robotSize by remember { mutableStateOf(prefs.robotSize) } // sm, md, lg
    var robotPreset by remember { mutableStateOf("top-left") }
    var serviceRunning by remember { mutableStateOf(false) }

    var statusBanner by remember {
        mutableStateOf("جاهز لتشغيل الروبوت الأخضر العائم فوق MT5 وPocket Option")
    }

    fun pushRobotSettings(presetOverride: String? = null) {
        prefs.robotSize = robotSize
        prefs.robotEnabled = robotVisible
        prefs.robotPaused = robotPaused
        if (!serviceRunning) return
        val updateIntent = Intent(context, GoldenVisionOverlayService::class.java).apply {
            action = GoldenVisionOverlayService.ACTION_UPDATE_SETTINGS
            putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_SIZE, robotSize)
            putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_VISIBLE, robotVisible)
            putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_PAUSED, robotPaused)
            if (presetOverride != null) {
                putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_PRESET, presetOverride)
            }
        }
        context.startService(updateIntent)
    }

    val overlayLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPerm = Settings.canDrawOverlays(context)
    }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotifPerm = granted
    }

    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val svcIntent = Intent(context, GoldenVisionOverlayService::class.java).apply {
                action = GoldenVisionOverlayService.ACTION_START
                putExtra(GoldenVisionOverlayService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(GoldenVisionOverlayService.EXTRA_MEDIA_DATA, result.data)
                putExtra(GoldenVisionOverlayService.EXTRA_SERVER_URL, serverUrl.trim())
                putExtra(GoldenVisionOverlayService.EXTRA_BALANCE, balanceText.toDoubleOrNull() ?: 1000.0)
                putExtra(GoldenVisionOverlayService.EXTRA_RISK_PERCENT, riskText.toDoubleOrNull() ?: 1.0)
                putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_SIZE, robotSize)
                putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_VISIBLE, robotVisible)
                putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_PAUSED, robotPaused)
                putExtra(GoldenVisionOverlayService.EXTRA_ROBOT_PRESET, robotPreset)
            }
            ContextCompat.startForegroundService(context, svcIntent)
            serviceRunning = true
            statusBanner = "الروبوت الأخضر العائم نشط الآن — يمكنك الخروج وفتح MT5 أو Pocket Option وسيبقى ظاهراً"
        } else {
            statusBanner = "تم رفض صلاحية التقاط الشاشة (MediaProjection)"
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GvCanvas)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "GOLDEN VISION SMART SCANNER",
            color = GvGoldBright,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "روبوت AI أخضر عائم يعمل في الخلفية فوق MT5 وPocket Option وTradingView عبر MediaProjection بدون طلب كلمة مرور التداول أو Session ID.",
            color = GvMuted,
            fontSize = 13.sp
        )

        // 1. Permissions Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(GvSurface, RoundedCornerShape(12.dp))
                .border(1.dp, GvBorder, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("1. الصلاحيات الرسمية", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("الظهور فوق التطبيقات الأخرى", color = Color.White, fontSize = 13.sp)
                    Text(
                        if (hasOverlayPerm) "مفعّلة" else "مطلوبة لبقاء الروبوت فوق MT5 وPocket Option",
                        color = if (hasOverlayPerm) GvLaser else GvMuted,
                        fontSize = 11.sp
                    )
                }
                OutlinedButton(onClick = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    overlayLauncher.launch(intent)
                }) {
                    Text(if (hasOverlayPerm) "تحديث" else "منح الصلاحية", color = GvGoldBright)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("الإشعارات الفورية", color = Color.White, fontSize = 13.sp)
                        Text(
                            if (hasNotifPerm) "مفعّلة" else "مطلوبة لإشعارات BUY/SELL واستمرار الخدمة",
                            color = if (hasNotifPerm) GvLaser else GvMuted,
                            fontSize = 11.sp
                        )
                    }
                    OutlinedButton(onClick = {
                        notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }) {
                        Text(if (hasNotifPerm) "مفعّلة" else "تفعيل", color = GvGoldBright)
                    }
                }
            }
        }

        // 2. Laser Robot Appearance & Behavior Settings
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(GvSurface, RoundedCornerShape(12.dp))
                .border(1.dp, GvBorder, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("2. إعدادات الروبوت العائم", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        robotVisible = !robotVisible
                        pushRobotSettings()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (robotVisible) "إخفاء الروبوت" else "إظهار الروبوت", color = GvLaser, fontSize = 12.sp)
                }
                OutlinedButton(
                    onClick = {
                        robotPaused = !robotPaused
                        pushRobotSettings()
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (robotPaused) "استئناف المسح" else "إيقاف مؤقت", color = GvGoldBright, fontSize = 12.sp)
                }
            }

            Text("حجم الروبوت:", color = GvMuted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("sm" to "صغير", "md" to "متوسط", "lg" to "كبير").forEach { (key, label) ->
                    val selected = robotSize == key
                    Button(
                        onClick = {
                            robotSize = key
                            pushRobotSettings()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selected) GvGold else Color(0xFF1A202B),
                            contentColor = if (selected) GvCanvas else Color.White
                        ),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(label, fontSize = 12.sp)
                    }
                }
            }

            Text("الموضع السريع:", color = GvMuted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("top-right" to "أعلى يمين", "top-left" to "أعلى يسار").forEach { (key, label) ->
                    OutlinedButton(
                        onClick = {
                            robotPreset = key
                            pushRobotSettings(key)
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(label, color = if (robotPreset == key) GvLaser else Color.White, fontSize = 12.sp)
                    }
                }
            }
        }

        // 3. Server & Risk Settings
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(GvSurface, RoundedCornerShape(12.dp))
                .border(1.dp, GvBorder, RoundedCornerShape(12.dp))
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("3. الخادم وإدارة المخاطر", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

            OutlinedTextField(
                value = serverUrl,
                onValueChange = { serverUrl = it },
                label = { Text("رابط خادم GOLDEN VISION API") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = balanceText,
                    onValueChange = { balanceText = it },
                    label = { Text("رصيد الحساب ($)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
                OutlinedTextField(
                    value = riskText,
                    onValueChange = { riskText = it },
                    label = { Text("نسبة المخاطرة (%)") },
                    singleLine = true,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Start / Stop Controls
        Button(
            onClick = {
                if (!Settings.canDrawOverlays(context)) {
                    statusBanner = "يرجى تفعيل صلاحية الظهور فوق التطبيقات أولاً"
                    return@Button
                }
                val mgr =
                    context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                mediaProjectionLauncher.launch(mgr.createScreenCaptureIntent())
            },
            colors = ButtonDefaults.buttonColors(containerColor = GvLaser, contentColor = GvCanvas),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("تشغيل الروبوت العائم (MediaProjection + Overlay)", fontWeight = FontWeight.Bold)
        }

        OutlinedButton(
            onClick = {
                val stopIntent = Intent(context, GoldenVisionOverlayService::class.java).apply {
                    action = GoldenVisionOverlayService.ACTION_STOP
                }
                context.startService(stopIntent)
                serviceRunning = false
                statusBanner = "تم إغلاق الخدمة العائمة"
            },
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
        ) {
            Text("إغلاق الخدمة العائمة بالكامل", color = Color(0xFFEF4444))
        }

        Text(
            text = statusBanner,
            color = GvGoldBright,
            fontSize = 12.sp
        )
    }
}
